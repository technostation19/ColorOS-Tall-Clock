# Clear Liquid Glass Tall Clock — Live Widget

A tall home-screen clock widget with a clear Liquid Glass-inspired panel.

## Live clock behaviour
The hour and minute are Android `TextClock` views, so the system updates their displayed time; the app does not need a continuously running service. The widget also refreshes its date when the date, time, time zone, or locale changes.

## Important Android/OxygenOS notes
- This is a standard Android home-screen widget, not a live wallpaper.
- The clock should keep showing current time while the widget remains placed on the home screen. Launchers can occasionally recreate widgets or delay rendering.
- After installation, add the widget from the launcher’s Widgets menu.
- If OxygenOS delays updates, check Settings → Battery → More settings / App battery management (wording varies) and avoid restricting Glass Tall Clock. Do not disable system-wide battery protections unnecessarily.
- A standard Android widget cannot guarantee a perfectly uninterrupted second-by-second animation; this widget displays hours and minutes and relies on the system `TextClock`.

## Build on phone using GitHub Actions
1. Upload all project files to a GitHub repository.
2. Open Actions → Build Android APK → Run workflow.
3. Download the `glass-tall-clock-debug-apk` artifact from the successful run.
4. Extract and install `app-debug.apk`.
5. Long-press home screen → Widgets → Glass Tall Clock.

## Limitations
This is a visual recreation using standard Android widget layouts. The glass is a transparent gradient and border, not true live refraction or blur. This source has not been compiled or device-tested in this environment.

package com.example.glasstallclock

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF10131B.toInt())
        }
        val title = TextView(this).apply {
            text = "Glass Tall Clock"
            textSize = 28f
            setTextColor(0xFFF5F6FA.toInt())
        }
        val body = TextView(this).apply {
            text = "Add the widget to your home screen:\\n\\n1. Long-press an empty area on the home screen.\\n2. Choose Widgets.\\n3. Find Glass Tall Clock.\\n4. Drag the tall clock widget onto your home screen.\\n\\nTip: resize it to a tall 2×3 or 2×4 area if your launcher allows it."
            textSize = 16f
            setTextColor(0xFFD1D5E0.toInt())
            setPadding(0, pad, 0, 0)
        }
        layout.addView(title)
        layout.addView(body)
        setContentView(layout)
    }
}

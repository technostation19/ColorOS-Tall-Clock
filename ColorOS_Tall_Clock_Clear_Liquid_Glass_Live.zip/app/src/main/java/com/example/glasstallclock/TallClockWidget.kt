package com.example.glasstallclock

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TallClockWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        manager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_LOCALE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    android.content.ComponentName(context, TallClockWidget::class.java)
                )
                ids.forEach { id -> updateWidget(context, manager, id) }
            }
        }
    }

    private fun updateWidget(
        context: Context,
        manager: AppWidgetManager,
        id: Int
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_tall_clock)
        views.setTextViewText(
            R.id.widget_date,
            SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())
        )
        manager.updateAppWidget(id, views)
    }
}
